﻿$(document).ready(function () {
    //    $('.contact-form .label').css("display", "none");

    //Set variables for watermarks
    var nametxt = "Name *";
    var emailtxt = "E-mail *";
    var phonetxt = "Phone Number *";


    //Set Watermark for Name

    $('.contact-form .txtName').addClass("lightText")
    // set default value
.val(nametxt)
    // onfocus action
.focus(function () {
    if ($(this).val() == nametxt) {
        $(this).removeClass("lightText").val("");
    }
    // focus lost action
}).blur(function () {
    if ($(this).val() == "") {
        $(this).val(nametxt).addClass("lightText");
    }
});

    //Set Watermark for Email

    $('.contact-form .txtEmail').addClass("lightText")
    // set default value
.val(emailtxt)
    // onfocus action
.focus(function () {
    if ($(this).val() == emailtxt) {
        $(this).removeClass("lightText").val("");
    }
    // focus lost action
}).blur(function () {
    if ($(this).val() == "") {
        $(this).val(emailtxt).addClass("lightText");
    }
});

    //Set Watermark for Phone

    $('.contact-form .txtPhone').addClass("lightText")
    // set default value
.val(phonetxt)
    // onfocus action
.focus(function () {
    if ($(this).val() == phonetxt) {
        $(this).removeClass("lightText").val("");
    }
    // focus lost action
}).blur(function () {
    if ($(this).val() == "") {
        $(this).val(phonetxt).addClass("lightText");
    }
});




    $('.submit').click(function (e) {

        if ($('.contact-form .txtPhone').val() === phonetxt || $('.contact-form .txtPhone').val().trim() == "") {

            $('.contact-form .txtPhone').val("");
            e.preventDefault();
        }
        if ($('.contact-form .txtEmail').val() === emailtxt || $('.contact-form .txtEmail').val().trim() == "") {
            e.preventDefault();

            $('.contact-form .txtEmail').val("");
        }
        if ($('.contact-form .txtName').val() === nametxt || $('.contact-form .txtName').val().trim() == "") {
            e.preventDefault();

            $('.contact-form .txtName').val("");
        }
    });
});